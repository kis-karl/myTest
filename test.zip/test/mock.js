(function () {
  let sqlData = JSON.parse(localStorage.getItem("testQuestion"));
  if (!sqlData) {
    if (confirm("是否载入mock数据？")) {
      sqlData = {
        变革创新: [
          {
            id: "1",
            type: "变革创新",
            describe:
              "有危机意识，能够明锐的发现组织、项目中存在问题和潜在的风险。",
            answer: [
              {
                score: 10,
                optionDesc: "A、卓越",
              },
              {
                score: 10,
                optionDesc: "B、优秀",
              },
              {
                score: 10,
                optionDesc: "B、良好",
              },
              {
                score: 10,
                optionDesc: "B、一般",
              },
            ],
          },
          {
            id: "2",
            type: "变革创新",
            describe:
              "加强自我内在建设对于工作有什么影响",
            answer: [
              {
                score: 10,
                optionDesc: "A、卓越",
              },
              {
                score: 10,
                optionDesc: "B、优秀",
              },
              {
                score: 10,
                optionDesc: "B、良好",
              },
              {
                score: 10,
                optionDesc: "B、一般",
              },
            ],
          },
        ],
        改革开放: [
          {
            id: "3",
            type: "改革开放",
            describe:
              "有危机意识，能够明锐的发现组织、项目中存在问题和潜在的风险。",
            answer: [
              {
                score: 10,
                optionDesc: "A、卓越",
              },
              {
                score: 10,
                optionDesc: "B、优秀",
              },
              {
                score: 10,
                optionDesc: "B、良好",
              },
              {
                score: 10,
                optionDesc: "B、一般",
              },
            ],
          },
        ],
      };
      localStorage.setItem("testQuestion", JSON.stringify(sqlData));
    }
  }
})();
